case 3:
        //     var name, species, habitat string
        //     var age int
        //     fmt.Println("Введите имя животного")
        //     fmt.Scan(&name)
        //     fmt.Println("Ваше животное травоядное/плотоядное")
        //     fmt.Scan(&species)
        //     fmt.Println("Введите возраст животного")
        //     fmt.Scan(&age)
        //     fmt.Println("Введите животное в каком месте обитает животное")
        //     fmt.Scan(&habitat)

        //     animals, err = animaldb.AddAnimal(db, name, species, age, habitat)
        //     if err!= nil {
        //         log.Fatal(err)
        //     }

        //     for _, animal := range animals {
        //         fmt.Printf("Добавлено животное: %s, %s, %d, %s\n", animal.Name, animal.Species, animal.Age, animal.Habitat)
        //     }